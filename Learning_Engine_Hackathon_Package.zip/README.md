# Learning Engine – Hackathon Package

## My Responsibility
This module is the learning logic behind the vocabulary app.

It:
- Tracks mastery per word
- Uses a 5-box spaced-repetition model
- Selects the next due/weak word
- Scores correct/wrong answers
- Logs wrong answers for AI diagnosis
- Calculates words seen vs words mastered

## Main File
`learning_engine.py`

## Required Vocabulary Format

```json
{
  "id": "w0001",
  "word_ar": "كِتَاب",
  "meaning_en": "book",
  "pos": "noun",
  "root": "ك ت ب",
  "tier": "1"
}
```

Each word MUST have a permanent unique `id`.

## Box Logic

| Box | Status | Review Delay |
|---|---|---|
| 1 | New / Weak | 1 interaction |
| 2 | Learning | 2 interactions |
| 3 | Improving | 4 interactions |
| 4 | Mastered | 8 interactions |
| 5 | Strongly Mastered | 16 interactions |

Correct answer: move up one box.
Wrong answer: reset to Box 1.

## Main Functions

```python
create_engine_state()
get_next_word(vocabulary, engine_state, tier)
submit_answer(vocabulary, engine_state, word_id, is_correct, user_answer, correct_answer)
tier_completion(vocabulary, engine_state, tier)
get_weak_words(vocabulary, engine_state, tier=None, limit=10)
get_recent_wrong_answers(engine_state, limit=10)
```

## Streamlit Integration

```python
import streamlit as st

from learning_engine import (
    create_engine_state,
    get_next_word,
    submit_answer,
    tier_completion
)

if "learning_engine" not in st.session_state:
    st.session_state.learning_engine = create_engine_state()

engine = st.session_state.learning_engine
```

Get next word:

```python
word = get_next_word(
    vocabulary,
    engine,
    tier="1"
)
```

Submit answer:

```python
submit_answer(
    vocabulary=vocabulary,
    engine_state=engine,
    word_id=word["id"],
    is_correct=True,
    user_answer="book",
    correct_answer="book"
)
```

Progress:

```python
progress = tier_completion(
    vocabulary,
    engine,
    tier="1"
)
```

## AI Diagnosis Integration

The AI member can consume:

```python
errors = get_recent_wrong_answers(
    engine,
    limit=10
)
```

Each wrong answer is stored as:

```python
{
    "word_id": "w0001",
    "word_ar": "كِتَاب",
    "meaning_en": "book",
    "pos": "noun",
    "root": "ك ت ب",
    "tier": "1",
    "user_answer": "pen",
    "correct_answer": "book",
    "timestamp": "..."
}
```

## MVP Persistence

For the hackathon demo, use `st.session_state`.

Do not add a database until the main learning flow is working.

## Definition of Done

- Correct answers increase mastery
- Wrong answers reset words to Box 1
- Weak words are prioritized
- Strong words appear less often
- Wrong answers are logged for AI
- Seen percentage is calculated
- Mastered percentage is calculated
- Streamlit member can import the module
- AI member can consume wrong-answer data
