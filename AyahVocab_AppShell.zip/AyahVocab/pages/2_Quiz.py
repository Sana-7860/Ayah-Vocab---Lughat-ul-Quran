"""
pages/2_Quiz.py -- Multiple choice quiz.

submit_answer() is a PLACEHOLDER. Member 4 (Learning Engine Dev) will replace
this with the real version that updates each word's spaced-repetition box
and appends to wrong_answers_log for Member 5's AI diagnosis step.
"""

import json
import random
import streamlit as st
from gamification import GameState, render_top_bar

st.set_page_config(page_title="Quiz | AyahVocab", page_icon="📝", layout="wide")

gs = GameState()
render_top_bar()

st.title("📝 Quiz")

tier = st.session_state.get("selected_tier", 50)
st.caption(f"Quiz -- Tier {tier}%")


@st.cache_data
def load_vocab(tier_num: int):
    with open(f"data/vocab_{tier_num}.json", "r", encoding="utf-8") as f:
        return json.load(f)


def submit_answer(word_id: str, is_correct: bool, word: dict, user_answer: str):
    """PLACEHOLDER -- Member 4 will replace this with real box-update logic.
    For now: award/deduct XP+hearts and log wrong answers in the exact shape
    Member 5's diagnose_weakness() expects."""
    if is_correct:
        gs.add_xp(10)
    else:
        gs.lose_heart()
        gs.log_wrong_answer(
            {
                "word_id": word_id,
                "word_ar": word["word_ar"],
                "meaning_en": word["meaning_en"],
                "pos": word.get("pos"),
                "root": word.get("root"),
                "user_answer": user_answer,
                "correct_answer": word["meaning_en"],
                "timestamp": str(st.session_state.get("last_active_date")),
            }
        )
    return is_correct


word_bank = load_vocab(tier)

if len(word_bank) < 4:
    st.warning("Need at least 4 words in this tier to build multiple-choice options. "
               "Add more dummy words or wait for the real vocab file.")
else:
    q_key = f"quiz_word_{tier}"
    if q_key not in st.session_state or st.session_state.get(f"{q_key}_answered", False):
        st.session_state[q_key] = random.choice(word_bank)
        st.session_state[f"{q_key}_answered"] = False
        wrong_options = random.sample(
            [w["meaning_en"] for w in word_bank if w["id"] != st.session_state[q_key]["id"]],
            k=min(3, len(word_bank) - 1),
        )
        options = wrong_options + [st.session_state[q_key]["meaning_en"]]
        random.shuffle(options)
        st.session_state[f"{q_key}_options"] = options

    current_word = st.session_state[q_key]
    options = st.session_state[f"{q_key}_options"]

    st.markdown(f"<h1 style='text-align:center'>{current_word['word_ar']}</h1>", unsafe_allow_html=True)
    st.markdown(
        f"<p style='text-align:center;color:gray'>{current_word['transliteration']}</p>",
        unsafe_allow_html=True,
    )
    st.write("**What does this word mean?**")

    choice = st.radio("Choose one:", options, key=f"{q_key}_choice", label_visibility="collapsed")

    if st.button("Submit answer") and not st.session_state[f"{q_key}_answered"]:
        is_correct = choice == current_word["meaning_en"]
        submit_answer(current_word["id"], is_correct, current_word, choice)
        st.session_state[f"{q_key}_answered"] = True
        if is_correct:
            st.success("Correct! +10 XP")
        else:
            st.error(f"Not quite -- correct answer was **{current_word['meaning_en']}**")

    if st.session_state.get(f"{q_key}_answered"):
        if st.button("Next question"):
            st.rerun()
