"""
pages/1_Learn.py -- Flashcard-style word review.

get_next_word() is a PLACEHOLDER. Member 4 (Learning Engine Dev) will replace
this with the real spaced-repetition version that picks the weakest word.
Until then it just cycles through the tier's word list in order.
"""

import json
import streamlit as st
from gamification import GameState, render_top_bar

st.set_page_config(page_title="Learn | AyahVocab", page_icon="📇", layout="wide")

gs = GameState()
render_top_bar()

st.title("📇 Flashcards")

tier = st.session_state.get("selected_tier", 50)
st.caption(f"Reviewing Tier {tier}% words")


@st.cache_data
def load_vocab(tier_num: int):
    with open(f"data/vocab_{tier_num}.json", "r", encoding="utf-8") as f:
        return json.load(f)


def get_next_word(tier_num: int, word_bank: list):
    """PLACEHOLDER -- Member 4 will replace this with real spaced-repetition
    logic (lowest box first). For now: cycle through the list using an index
    stored in session_state so the demo is testable end-to-end."""
    idx_key = f"learn_idx_{tier_num}"
    if idx_key not in st.session_state:
        st.session_state[idx_key] = 0
    idx = st.session_state[idx_key] % len(word_bank)
    return word_bank[idx]


def advance_word(tier_num: int, word_bank: list):
    idx_key = f"learn_idx_{tier_num}"
    st.session_state[idx_key] = (st.session_state.get(idx_key, 0) + 1) % len(word_bank)


word_bank = load_vocab(tier)

if not word_bank:
    st.warning("No words found for this tier yet.")
else:
    word = get_next_word(tier, word_bank)

    card = st.container(border=True)
    with card:
        st.markdown(f"<h1 style='text-align:center'>{word['word_ar']}</h1>", unsafe_allow_html=True)
        st.markdown(f"<p style='text-align:center;color:gray'>{word['transliteration']}</p>", unsafe_allow_html=True)

        show_key = f"show_meaning_{word['id']}"
        if show_key not in st.session_state:
            st.session_state[show_key] = False

        if st.session_state[show_key]:
            st.success(f"**Meaning:** {word['meaning_en']}")
            if word.get("root"):
                st.caption(f"Root: {word['root']}  ·  Part of speech: {word.get('pos', '—')}")
        else:
            if st.button("Reveal meaning", use_container_width=True):
                st.session_state[show_key] = True
                st.rerun()

    col1, col2 = st.columns(2)
    with col1:
        if st.button("😅 I didn't know this", use_container_width=True):
            gs.lose_heart()
            advance_word(tier, word_bank)
            st.rerun()
    with col2:
        if st.button("✅ I knew this", use_container_width=True):
            gs.add_xp(10)
            advance_word(tier, word_bank)
            st.rerun()
