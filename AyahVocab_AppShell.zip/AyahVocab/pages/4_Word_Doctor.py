"""
pages/4_Word_Doctor.py -- Chat-style page (placeholder for now).

get_diagnosis() and the real chat call are PLACEHOLDERS. Member 5
(AI Integration Dev) will replace them with real Grok API calls:
  - diagnose_weakness(wrong_answers_log)
  - word_doctor_chat(user_question, word_bank_context)
"""

import streamlit as st
from gamification import GameState, render_top_bar

st.set_page_config(page_title="Word Doctor | AyahVocab", page_icon="💬", layout="wide")

gs = GameState()
render_top_bar()

st.title("💬 Word Doctor")
st.caption("Ask about any word you've struggled with. (AI answers are placeholders until Member 5 wires up Grok.)")


def get_diagnosis(wrong_answers_log: list):
    """PLACEHOLDER -- Member 5 will replace this with a real call to
    diagnose_weakness(wrong_answers_log) using the Grok API.
    Expected real return shape: {"diagnosis": str, "recommended_word_ids": [str, ...]}"""
    if not wrong_answers_log:
        return {"diagnosis": "No mistakes logged yet -- do a quiz first!", "recommended_word_ids": []}
    words_missed = ", ".join(sorted({e["word_ar"] for e in wrong_answers_log}))
    return {
        "diagnosis": f"(placeholder) You've missed: {words_missed}. "
                     f"Once Grok is connected, this box will show the real pattern behind these misses.",
        "recommended_word_ids": [e["word_id"] for e in wrong_answers_log[:5]],
    }


def word_doctor_chat(user_question: str):
    """PLACEHOLDER -- Member 5 will replace this with a real call to
    word_doctor_chat(user_question, word_bank_context) using the Grok API."""
    return (
        "(placeholder response) I'm not connected to Grok yet -- once Member 5 "
        "wires up the AI layer, I'll answer your question about Qur'anic vocabulary here."
    )


st.subheader("📌 Diagnosis from your recent mistakes")
if st.button("Run diagnosis on my wrong answers"):
    result = get_diagnosis(st.session_state.get("wrong_answers_log", []))
    st.info(result["diagnosis"])
    if result["recommended_word_ids"]:
        st.write("Recommended words to re-practice:", ", ".join(result["recommended_word_ids"]))

st.markdown("---")
st.subheader("💬 Ask a question")

if "chat_history" not in st.session_state:
    st.session_state["chat_history"] = []

for role, msg in st.session_state["chat_history"]:
    with st.chat_message(role):
        st.write(msg)

question = st.chat_input("Ask about a word, e.g. 'why does khabara mean informed here?'")
if question:
    st.session_state["chat_history"].append(("user", question))
    answer = word_doctor_chat(question)
    st.session_state["chat_history"].append(("assistant", answer))
    st.rerun()
