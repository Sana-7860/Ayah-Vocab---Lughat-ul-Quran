"""
pages/3_Progress.py -- XP, streak, hearts, badges earned, progress per tier.

Tier completion (percent_seen / percent_mastered) is stubbed with dummy
numbers here -- Member 4's tier_completion() function will replace the
dummy_tier_completion() call below once the Learning Engine is wired in.
"""

import streamlit as st
from gamification import GameState, render_top_bar, TIER_BADGES

st.set_page_config(page_title="Progress | AyahVocab", page_icon="📊", layout="wide")

gs = GameState()
render_top_bar()

st.title("📊 Your Progress")

col1, col2, col3 = st.columns(3)
col1.metric("Total XP", st.session_state["xp"])
col2.metric("Current streak", f"{st.session_state['streak_days']} days")
col3.metric("Hearts", f"{st.session_state['hearts']} / 5")

st.markdown("---")
st.subheader("Tier completion")


def dummy_tier_completion(tier_num: int):
    """PLACEHOLDER -- Member 4 will replace this with real numbers from
    tier_completion(tier, word_bank, word_state). Returns (percent_seen, percent_mastered)."""
    dummy_values = {50: (40, 20), 65: (10, 0), 85: (0, 0)}
    return dummy_values.get(tier_num, (0, 0))


for tier in (50, 65, 85):
    percent_seen, percent_mastered = dummy_tier_completion(tier)
    st.write(f"**Tier {tier}%**")
    st.progress(percent_mastered / 100, text=f"Mastered: {percent_mastered}%  ·  Seen: {percent_seen}%")
    gs.check_tier_badge(tier, percent_mastered)

st.markdown("---")
st.subheader("🏅 Badges earned")

if st.session_state["badges"]:
    badge_cols = st.columns(len(st.session_state["badges"]))
    for col, badge in zip(badge_cols, st.session_state["badges"]):
        col.success(badge)
else:
    st.caption("No badges yet -- master a tier to earn one.")

st.markdown("---")
st.subheader("League")
st.info(f"Current league: **{gs.get_league()}**")
st.caption("Bronze → Silver → Gold as you complete tiers 50% → 65% → 85%.")
